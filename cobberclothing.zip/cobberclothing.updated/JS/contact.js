document.getElementById("contact-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevents the form from submitting the traditional way

    // Get form values
    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const address = document.getElementById("address").value;
    const reach = document.querySelector('input[name="reach"]:checked');
    const comments = document.getElementById("comments").value;
    const reason = document.getElementById("drop").value;

    // Simple client-side validation
    if (!firstName || !lastName || !email || !phone || !address || !reach) {
        alert("Please fill out all required fields.");
        return;
    }

    // If validation passes, redirect to confirmation page
    localStorage.setItem("firstName", firstName);
    localStorage.setItem("lastName", lastName);
    localStorage.setItem("email", email);
    localStorage.setItem("phone", phone);
    localStorage.setItem("address", address);
    localStorage.setItem("reach", reach.value);
    localStorage.setItem("comments", comments);
    localStorage.setItem("reason", reason);

    // Redirect to confirmation page
    window.location.href = "confirmation.html";
});
